package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RequestsController {

    public void showRequestsPage(Stage stage, int userId, String userName) {

        // ==========================================
        // HEADER
        // ==========================================

        Label logo = new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 40px;" +
                "-fx-min-height: 40px;" +
                "-fx-max-width: 40px;" +
                "-fx-max-height: 40px;"
        );

        Label title = new Label("Requests");

        title.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox header = new HBox(12, logo, title);

        header.setAlignment(Pos.CENTER_LEFT);

        header.setPadding(
                new Insets(18, 25, 18, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );

        // ==========================================
        // BACK BUTTON
        // ==========================================

        Button backButton = new Button("← DASHBOARD");

        backButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event -> {

            new DashboardController().showDashboard(
                    stage,
                    userId,
                    userName
            );

        });

        // ==========================================
        // PAGE TITLE
        // ==========================================

        Label heading = new Label("Exchange Requests");

        heading.setStyle(
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label description = new Label(
                "Manage students who want to exchange skills with you."
        );

        description.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );

        Label sectionTitle = new Label("RECEIVED REQUESTS");

        sectionTitle.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #6B7280;"
        );

        // ==========================================
        // REQUEST LIST
        // ==========================================

        VBox requestList = new VBox(18);

        requestList.setPadding(new Insets(5));

        loadRequests(userId, requestList);

        ScrollPane scrollPane = new ScrollPane(requestList);

        scrollPane.setFitToWidth(true);

        scrollPane.setPrefHeight(480);

        scrollPane.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background: transparent;"
        );

        // ==========================================
        // CONTENT
        // ==========================================

        VBox content = new VBox(18);

        content.setPadding(new Insets(30));

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                backButton,
                heading,
                description,
                sectionTitle,
                scrollPane
        );

        // ==========================================
        // ROOT
        // ==========================================

        BorderPane root = new BorderPane();

        root.setTop(header);

        root.setCenter(content);

        Scene scene = new Scene(
                root,
                1000,
                750
        );

        stage.setTitle("SkillSwap - Requests");

        stage.setScene(scene);

        stage.setMinWidth(850);

        stage.setMinHeight(650);

        stage.show();
    }

    // ==========================================
    // LOAD REQUESTS
    // ==========================================

    private void loadRequests(int userId, VBox requestList) {

        String sql =
                "SELECT " +
                "er.request_id, " +
                "er.sender_id, " +
                "u.name, " +
                "u.college, " +
                "er.skill_offered, " +
                "er.skill_requested, " +
                "er.status " +
                "FROM exchange_requests er " +
                "JOIN users u " +
                "ON er.sender_id = u.user_id " +
                "WHERE er.receiver_id = ? " +
                "ORDER BY er.request_id DESC";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);

            ResultSet rs =
                    ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                int requestId =
                        rs.getInt("request_id");

                String name =
                        rs.getString("name");

                String college =
                        rs.getString("college");

                String offered =
                        rs.getString("skill_offered");

                String requested =
                        rs.getString("skill_requested");

                String status =
                        rs.getString("status");

                // ==================================
                // PROFILE INITIAL
                // ==================================

                Label profileIcon =
                        new Label(getInitial(name));

                profileIcon.setStyle(
                        "-fx-background-color: #EEF2FF;" +
                        "-fx-text-fill: #4F46E5;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-alignment: center;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 50px;" +
                        "-fx-min-height: 50px;" +
                        "-fx-max-width: 50px;" +
                        "-fx-max-height: 50px;"
                );

                // ==================================
                // NAME
                // ==================================

                Label nameLabel =
                        new Label(name);

                nameLabel.setStyle(
                        "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );

                Label collegeLabel =
                        new Label(
                                college == null
                                        ? "College not provided"
                                        : college
                        );

                collegeLabel.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-text-fill: #6B7280;"
                );

                VBox personInfo =
                        new VBox(
                                4,
                                nameLabel,
                                collegeLabel
                        );

                HBox personHeader =
                        new HBox(
                                12,
                                profileIcon,
                                personInfo
                        );

                personHeader.setAlignment(
                        Pos.CENTER_LEFT
                );

                // ==================================
                // EXCHANGE INFORMATION
                // ==================================

                Label exchangeLabel =
                        new Label("SKILL EXCHANGE");

                exchangeLabel.setStyle(
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #9CA3AF;"
                );

                Label exchangeText =
                        new Label(
                                "Offers: " +
                                offered +
                                "\nWants to learn: " +
                                requested
                        );

                exchangeText.setStyle(
                        "-fx-font-size: 14px;" +
                        "-fx-text-fill: #374151;"
                );

                VBox exchangeInfo =
                        new VBox(
                                6,
                                exchangeLabel,
                                exchangeText
                        );

                // ==================================
                // STATUS
                // ==================================

                Label statusLabel =
                        new Label(status);

                statusLabel.setStyle(
                        getStatusStyle(status)
                );

                // ==================================
                // BUTTONS
                // ==================================

                Button acceptButton =
                        new Button("✓ ACCEPT");

                Button rejectButton =
                        new Button("✕ REJECT");

                acceptButton.setPrefWidth(120);

                rejectButton.setPrefWidth(120);

                acceptButton.setPrefHeight(38);

                rejectButton.setPrefHeight(38);

                acceptButton.setStyle(
                        "-fx-background-color: #16A34A;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-cursor: hand;"
                );

                rejectButton.setStyle(
                        "-fx-background-color: #FEE2E2;" +
                        "-fx-text-fill: #DC2626;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-cursor: hand;"
                );

                HBox buttons =
                        new HBox(
                                10,
                                acceptButton,
                                rejectButton
                        );

                buttons.setAlignment(
                        Pos.CENTER_RIGHT
                );

                // ==================================
                // DISABLE IF ALREADY DECIDED
                // ==================================

                if (!"PENDING".equals(status)) {

                    acceptButton.setDisable(true);

                    rejectButton.setDisable(true);
                }

                // ==================================
                // ACCEPT ACTION
                // ==================================

                acceptButton.setOnAction(event -> {

                    updateRequestStatus(
                            requestId,
                            "ACCEPTED",
                            statusLabel,
                            acceptButton,
                            rejectButton
                    );

                });

                // ==================================
                // REJECT ACTION
                // ==================================

                rejectButton.setOnAction(event -> {

                    updateRequestStatus(
                            requestId,
                            "REJECTED",
                            statusLabel,
                            acceptButton,
                            rejectButton
                    );

                });

                // ==================================
                // SPACER
                // ==================================

                Region spacer = new Region();

                HBox.setHgrow(
                        spacer,
                        Priority.ALWAYS
                );

                HBox statusRow =
                        new HBox(
                                statusLabel,
                                spacer,
                                buttons
                        );

                statusRow.setAlignment(
                        Pos.CENTER_LEFT
                );

                // ==================================
                // REQUEST CARD
                // ==================================

                VBox card =
                        new VBox(
                                18,
                                personHeader,
                                exchangeInfo,
                                statusRow
                        );

                card.setPadding(
                        new Insets(22)
                );

                card.setMaxWidth(
                        Double.MAX_VALUE
                );

                card.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 14px;"
                );

                requestList
                        .getChildren()
                        .add(card);
            }

            // ==================================
            // NO REQUESTS
            // ==================================

            if (!found) {

                Label emptyTitle =
                        new Label("No requests yet");

                emptyTitle.setStyle(
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );

                Label emptyText =
                        new Label(
                                "When another student sends " +
                                "you a skill exchange request, " +
                                "it will appear here."
                        );

                emptyText.setStyle(
                        "-fx-font-size: 14px;" +
                        "-fx-text-fill: #6B7280;"
                );

                VBox emptyBox =
                        new VBox(
                                8,
                                emptyTitle,
                                emptyText
                        );

                emptyBox.setAlignment(
                        Pos.CENTER
                );

                emptyBox.setPadding(
                        new Insets(60)
                );

                requestList
                        .getChildren()
                        .add(emptyBox);
            }

            rs.close();

            ps.close();

            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            requestList
                    .getChildren()
                    .add(
                            new Label(
                                    "Unable to load requests."
                            )
                    );
        }
    }

    // ==========================================
    // UPDATE REQUEST STATUS
    // ==========================================

    private void updateRequestStatus(
            int requestId,
            String newStatus,
            Label statusLabel,
            Button acceptButton,
            Button rejectButton) {

        String sql =
                "UPDATE exchange_requests " +
                "SET status = ? " +
                "WHERE request_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(
                    1,
                    newStatus
            );

            ps.setInt(
                    2,
                    requestId
            );

            ps.executeUpdate();

            ps.close();

            con.close();

            // Update UI immediately

            statusLabel.setText(newStatus);

            statusLabel.setStyle(
                    getStatusStyle(newStatus)
            );

            acceptButton.setDisable(true);

            rejectButton.setDisable(true);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // ==========================================
    // STATUS STYLE
    // ==========================================

    private String getStatusStyle(String status) {

        if ("ACCEPTED".equals(status)) {

            return
                    "-fx-background-color: #DCFCE7;" +
                    "-fx-text-fill: #15803D;" +
                    "-fx-font-weight: bold;" +
                    "-fx-padding: 6px 12px;" +
                    "-fx-background-radius: 20px;";
        }

        if ("REJECTED".equals(status)) {

            return
                    "-fx-background-color: #FEE2E2;" +
                    "-fx-text-fill: #B91C1C;" +
                    "-fx-font-weight: bold;" +
                    "-fx-padding: 6px 12px;" +
                    "-fx-background-radius: 20px;";
        }

        return
                "-fx-background-color: #FEF3C7;" +
                "-fx-text-fill: #B45309;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 6px 12px;" +
                "-fx-background-radius: 20px;";
    }

    // ==========================================
    // GET INITIAL
    // ==========================================

    private String getInitial(String name) {

        if (name == null ||
                name.trim().isEmpty()) {

            return "S";
        }

        return name
                .trim()
                .substring(0, 1)
                .toUpperCase();
    }
}
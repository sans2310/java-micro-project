package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProfileController {

    public void showProfilePage(Stage stage, int userId, String userName) {

        // =====================================================
        // HEADER
        // =====================================================

        Label logo = new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 12px;" +
                "-fx-min-width: 42px;" +
                "-fx-min-height: 42px;" +
                "-fx-max-width: 42px;" +
                "-fx-max-height: 42px;"
        );

        Label appName = new Label("SkillSwap");

        appName.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox branding = new HBox(10, logo, appName);
        branding.setAlignment(Pos.CENTER_LEFT);

        Label userLabel =
                new Label("Welcome, " + userName);

        userLabel.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        Button logoutButton =
                new Button("Logout");

        logoutButton.setPrefHeight(38);

        logoutButton.setStyle(
                "-fx-background-color: #FEE2E2;" +
                "-fx-text-fill: #DC2626;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 9px;" +
                "-fx-padding: 0 18px;" +
                "-fx-cursor: hand;"
        );

        logoutButton.setOnAction(event ->
                new LoginController().showLoginPage(stage)
        );

        Region headerSpacer = new Region();

        HBox.setHgrow(
                headerSpacer,
                Priority.ALWAYS
        );

        HBox header = new HBox(
                15,
                branding,
                headerSpacer,
                userLabel,
                logoutButton
        );

        header.setAlignment(Pos.CENTER_LEFT);

        header.setPadding(
                new Insets(15, 25, 15, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );

        // =====================================================
        // SIDEBAR
        // =====================================================

        Label sideLogo = new Label("S");

        sideLogo.setStyle(
                "-fx-background-color: #6366F1;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 10px;" +
                "-fx-min-width: 36px;" +
                "-fx-min-height: 36px;" +
                "-fx-max-width: 36px;" +
                "-fx-max-height: 36px;"
        );

        Label sideTitle =
                new Label("SkillSwap");

        sideTitle.setStyle(
                "-fx-font-size: 19px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: white;"
        );

        HBox sideBrand =
                new HBox(
                        10,
                        sideLogo,
                        sideTitle
                );

        sideBrand.setAlignment(
                Pos.CENTER_LEFT
        );

        Label menuTitle =
                new Label("MAIN MENU");

        menuTitle.setStyle(
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #9CA3AF;"
        );

        // =====================================================
        // SIDEBAR BUTTONS
        // =====================================================

        Button homeButton =
                createMenuButton(
                        "⌂",
                        "Home"
                );

        Button profileButton =
                createMenuButton(
                        "●",
                        "My Profile"
                );

        Button requestsButton =
                createMenuButton(
                        "✉",
                        "Requests"
                );

        VBox sidebar =
                new VBox(8);

        sidebar.setPadding(
                new Insets(25, 14, 25, 14)
        );

        sidebar.setPrefWidth(220);

        sidebar.setStyle(
                "-fx-background-color: #111827;"
        );

        Region sideSpacer =
                new Region();

        VBox.setVgrow(
                sideSpacer,
                Priority.ALWAYS
        );

        Label bottomText =
                new Label("Learn • Teach • Connect");

        bottomText.setStyle(
                "-fx-text-fill: #6B7280;" +
                "-fx-font-size: 11px;"
        );

        sidebar.getChildren().addAll(
                sideBrand,
                menuTitle,
                homeButton,
                profileButton,
                requestsButton,
                sideSpacer,
                bottomText
        );

        // =====================================================
        // PROFILE TITLE
        // =====================================================

        Label pageTitle =
                new Label("My Profile");

        pageTitle.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label subtitle =
                new Label(
                        "Manage your personal information and tell others about yourself."
                );

        subtitle.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox titleBox =
                new VBox(
                        7,
                        pageTitle,
                        subtitle
                );

        // =====================================================
        // PROFILE HEADER
        // =====================================================

        Label avatar =
                new Label(
                        getInitial(userName)
                );

        avatar.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 70px;" +
                "-fx-min-height: 70px;" +
                "-fx-max-width: 70px;" +
                "-fx-max-height: 70px;"
        );

        Label profileName =
                new Label(userName);

        profileName.setStyle(
                "-fx-font-size: 21px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label profileText =
                new Label(
                        "Your SkillSwap profile"
                );

        profileText.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox profileInfo =
                new VBox(
                        5,
                        profileName,
                        profileText
                );

        HBox profileHeader =
                new HBox(
                        18,
                        avatar,
                        profileInfo
                );

        profileHeader.setAlignment(
                Pos.CENTER_LEFT
        );

        // =====================================================
        // FORM FIELDS
        // =====================================================

        Label nameLabel =
                createFieldLabel("Full Name");

        TextField nameField =
                createTextField();

        Label emailLabel =
                createFieldLabel("Email");

        TextField emailField =
                createTextField();

        emailField.setEditable(false);

        emailField.setStyle(
                "-fx-background-color: #F3F4F6;" +
                "-fx-text-fill: #6B7280;" +
                "-fx-background-radius: 9px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 9px;" +
                "-fx-padding: 10px;"
        );

        Label collegeLabel =
                createFieldLabel("College");

        TextField collegeField =
                createTextField();

        Label bioLabel =
                createFieldLabel("About Me");

        TextArea bioField =
                new TextArea();

        bioField.setWrapText(true);

        bioField.setPrefRowCount(5);

        bioField.setStyle(
                "-fx-background-color: white;" +
                "-fx-control-inner-background: white;" +
                "-fx-background-radius: 9px;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 9px;" +
                "-fx-padding: 10px;"
        );

        // =====================================================
        // LOAD PROFILE
        // =====================================================

        loadProfile(
                userId,
                nameField,
                emailField,
                collegeField,
                bioField
        );

        // =====================================================
        // MESSAGE
        // =====================================================

        Label message =
                new Label();

        message.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;"
        );

        // =====================================================
        // SAVE BUTTON
        // =====================================================

        Button updateButton =
                new Button("SAVE CHANGES");

        updateButton.setPrefHeight(45);

        updateButton.setPrefWidth(180);

        updateButton.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 9px;" +
                "-fx-cursor: hand;"
        );

        updateButton.setOnMouseEntered(event ->
                updateButton.setStyle(
                        "-fx-background-color: #4338CA;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )
        );

        updateButton.setOnMouseExited(event ->
                updateButton.setStyle(
                        "-fx-background-color: #4F46E5;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )
        );

        updateButton.setOnAction(event -> {

            updateProfile(
                    userId,
                    nameField.getText(),
                    collegeField.getText(),
                    bioField.getText(),
                    message
            );

        });

        // =====================================================
        // BACK BUTTON
        // =====================================================

        Button backButton =
                new Button("← Back to Dashboard");

        backButton.setPrefHeight(45);

        backButton.setStyle(
                "-fx-background-color: white;" +
                "-fx-text-fill: #374151;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 9px;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 9px;" +
                "-fx-padding: 0 18px;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event ->

                new DashboardController()
                        .showDashboard(
                                stage,
                                userId,
                                nameField.getText()
                        )

        );

        HBox buttons =
                new HBox(
                        12,
                        updateButton,
                        backButton
                );

        buttons.setAlignment(
                Pos.CENTER_LEFT
        );

        // =====================================================
        // FORM CARD
        // =====================================================

        VBox formCard =
                new VBox(13);

        formCard.setPadding(
                new Insets(25)
        );

        formCard.setMaxWidth(
                Double.MAX_VALUE
        );

        formCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 16px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 16px;"
        );

        formCard.getChildren().addAll(
                profileHeader,
                createSeparator(),
                nameLabel,
                nameField,
                emailLabel,
                emailField,
                collegeLabel,
                collegeField,
                bioLabel,
                bioField,
                buttons,
                message
        );

        // =====================================================
        // MAIN CONTENT
        // =====================================================

        VBox content =
                new VBox(25);

        content.setPadding(
                new Insets(35, 40, 35, 40)
        );

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                titleBox,
                formCard
        );

        VBox.setVgrow(
                formCard,
                Priority.ALWAYS
        );

        // =====================================================
        // SIDEBAR ACTIONS
        // =====================================================

        homeButton.setOnAction(event -> {

            new DashboardController()
                    .showDashboard(
                            stage,
                            userId,
                            userName
                    );

        });

        profileButton.setOnAction(event -> {

            showProfilePage(
                    stage,
                    userId,
                    userName
            );

        });

        requestsButton.setOnAction(event -> {

            new RequestsController()
                    .showRequestsPage(
                            stage,
                            userId,
                            userName
                    );

        });

        // =====================================================
        // ROOT
        // =====================================================

        BorderPane root =
                new BorderPane();

        root.setTop(header);

        root.setLeft(sidebar);

        root.setCenter(content);

        Scene scene =
                new Scene(
                        root,
                        1150,
                        720
                );

        stage.setTitle(
                "SkillSwap - My Profile"
        );

        stage.setScene(scene);

        stage.setMinWidth(1000);

        stage.setMinHeight(650);

        stage.show();
    }

    // =========================================================
    // MENU BUTTON
    // =========================================================

    private Button createMenuButton(
            String icon,
            String text) {

        Label iconLabel =
                new Label(icon);

        iconLabel.setStyle(
                "-fx-text-fill: #A5B4FC;" +
                "-fx-font-size: 16px;"
        );

        Label textLabel =
                new Label(text);

        textLabel.setStyle(
                "-fx-text-fill: #D1D5DB;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;"
        );

        HBox content =
                new HBox(
                        13,
                        iconLabel,
                        textLabel
                );

        content.setAlignment(
                Pos.CENTER_LEFT
        );

        // Prevent graphic from blocking button clicks
        content.setMouseTransparent(true);

        Button button =
                new Button();

        button.setGraphic(content);

        button.setMaxWidth(
                Double.MAX_VALUE
        );

        button.setPrefHeight(46);

        button.setAlignment(
                Pos.CENTER_LEFT
        );

        button.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background-radius: 9px;" +
                "-fx-cursor: hand;"
        );

        button.setOnMouseEntered(event ->
                button.setStyle(
                        "-fx-background-color: #1F2937;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )
        );

        button.setOnMouseExited(event ->
                button.setStyle(
                        "-fx-background-color: transparent;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )
        );

        return button;
    }

    // =========================================================
    // FIELD LABEL
    // =========================================================

    private Label createFieldLabel(
            String text) {

        Label label =
                new Label(text);

        label.setStyle(
                "-fx-font-size: 12px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        return label;
    }

    // =========================================================
    // TEXT FIELD
    // =========================================================

    private TextField createTextField() {

        TextField field =
                new TextField();

        field.setPrefHeight(42);

        field.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 9px;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 9px;" +
                "-fx-padding: 10px;"
        );

        return field;
    }

    // =========================================================
    // SEPARATOR
    // =========================================================

    private Region createSeparator() {

        Region separator =
                new Region();

        separator.setPrefHeight(1);

        separator.setMaxWidth(
                Double.MAX_VALUE
        );

        separator.setStyle(
                "-fx-background-color: #E5E7EB;"
        );

        return separator;
    }

    // =========================================================
    // GET INITIAL
    // =========================================================

    private String getInitial(
            String name) {

        if (name == null ||
                name.trim().isEmpty()) {

            return "S";
        }

        return name
                .trim()
                .substring(0, 1)
                .toUpperCase();
    }

    // =========================================================
    // LOAD PROFILE FROM DATABASE
    // =========================================================

    private void loadProfile(
            int userId,
            TextField nameField,
            TextField emailField,
            TextField collegeField,
            TextArea bioField) {

        String sql =
                "SELECT name, email, college, bio " +
                "FROM users " +
                "WHERE user_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(
                    1,
                    userId
            );

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                nameField.setText(
                        rs.getString("name")
                );

                emailField.setText(
                        rs.getString("email")
                );

                String college =
                        rs.getString("college");

                if (college != null) {

                    collegeField.setText(
                            college
                    );
                }

                String bio =
                        rs.getString("bio");

                if (bio != null) {

                    bioField.setText(
                            bio
                    );
                }
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    // =========================================================
    // UPDATE PROFILE IN DATABASE
    // =========================================================

    private void updateProfile(
            int userId,
            String name,
            String college,
            String bio,
            Label message) {

        if (name.trim().isEmpty()) {

            message.setStyle(
                    "-fx-text-fill: #DC2626;" +
                    "-fx-font-size: 13px;" +
                    "-fx-font-weight: bold;"
            );

            message.setText(
                    "Name cannot be empty."
            );

            return;
        }

        String sql =
                "UPDATE users " +
                "SET name = ?, college = ?, bio = ? " +
                "WHERE user_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(
                    1,
                    name.trim()
            );

            ps.setString(
                    2,
                    college.trim()
            );

            ps.setString(
                    3,
                    bio.trim()
            );

            ps.setInt(
                    4,
                    userId
            );

            ps.executeUpdate();

            ps.close();
            con.close();

            message.setStyle(
                    "-fx-text-fill: #16A34A;" +
                    "-fx-font-size: 13px;" +
                    "-fx-font-weight: bold;"
            );

            message.setText(
                    "Profile updated successfully."
            );

        } catch (Exception e) {

            message.setStyle(
                    "-fx-text-fill: #DC2626;" +
                    "-fx-font-size: 13px;" +
                    "-fx-font-weight: bold;"
            );

            message.setText(
                    "Could not update profile."
            );

            e.printStackTrace();
        }
    }
}
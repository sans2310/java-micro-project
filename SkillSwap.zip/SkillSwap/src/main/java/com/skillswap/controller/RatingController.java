package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RatingController {

    public void showRatingPage(Stage stage, int userId, String userName) {

        // =========================
        // TOP HEADER
        // =========================

        HBox header = new HBox(15);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(18, 28, 18, 28));

        Label logo = new Label("S");
        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-min-width: 42px;" +
                "-fx-min-height: 42px;" +
                "-fx-background-radius: 12px;"
        );

        VBox brandBox = new VBox(2);

        Label brand = new Label("SkillSwap");
        brand.setStyle(
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label subtitle = new Label("Share your experience");
        subtitle.setStyle(
                "-fx-font-size: 12px;" +
                "-fx-text-fill: #6B7280;"
        );

        brandBox.getChildren().addAll(brand, subtitle);

        Region headerSpacer = new Region();
        HBox.setHgrow(headerSpacer, Priority.ALWAYS);

        Label userLabel = new Label("Hi, " + userName);
        userLabel.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        header.getChildren().addAll(
                logo,
                brandBox,
                headerSpacer,
                userLabel
        );

        // =========================
        // PAGE TITLE
        // =========================

        Label title = new Label("Rate Your Skill Exchange");
        title.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label info = new Label(
                "Rate students you have completed an accepted exchange with."
        );
        info.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox titleBox = new VBox(7);
        titleBox.getChildren().addAll(title, info);

        // =========================
        // RATING LIST
        // =========================

        VBox ratingList = new VBox(18);
        ratingList.setPadding(new Insets(5, 0, 20, 0));

        loadPartners(userId, ratingList);

        ScrollPane scrollPane = new ScrollPane(ratingList);
        scrollPane.setFitToWidth(true);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        scrollPane.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background: transparent;"
        );

        // =========================
        // BACK BUTTON
        // =========================

        Button backButton = new Button("←  BACK TO DASHBOARD");

        backButton.setPrefHeight(42);
        backButton.setPrefWidth(220);

        backButton.setStyle(
                "-fx-background-color: #E5E7EB;" +
                "-fx-text-fill: #374151;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 10px;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnMouseEntered(event ->
                backButton.setStyle(
                        "-fx-background-color: #D1D5DB;" +
                        "-fx-text-fill: #111827;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-cursor: hand;"
                )
        );

        backButton.setOnMouseExited(event ->
                backButton.setStyle(
                        "-fx-background-color: #E5E7EB;" +
                        "-fx-text-fill: #374151;" +
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-cursor: hand;"
                )
        );

        backButton.setOnAction(event ->
                new DashboardController().showDashboard(
                        stage,
                        userId,
                        userName
                )
        );

        // =========================
        // MAIN CONTENT
        // =========================

        VBox content = new VBox(20);

        content.setPadding(
                new Insets(30, 45, 30, 45)
        );

        content.getChildren().addAll(
                titleBox,
                scrollPane,
                backButton
        );

        VBox.setVgrow(
                scrollPane,
                Priority.ALWAYS
        );

        // =========================
        // ROOT
        // =========================

        BorderPane root = new BorderPane();

        root.setTop(header);
        root.setCenter(content);

        root.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        Scene scene = new Scene(
                root,
                1000,
                720
        );

        stage.setTitle("SkillSwap - Ratings");
        stage.setScene(scene);
        stage.show();
    }

    // =========================================================
    // LOAD ACCEPTED EXCHANGE PARTNERS
    // =========================================================

    private void loadPartners(
            int userId,
            VBox ratingList) {

        String sql =
                "SELECT DISTINCT u.user_id, u.name, u.college " +
                "FROM exchange_requests er " +
                "JOIN users u " +
                "ON u.user_id = " +
                "CASE " +
                "WHEN er.sender_id = ? " +
                "THEN er.receiver_id " +
                "ELSE er.sender_id " +
                "END " +
                "WHERE (er.sender_id = ? " +
                "OR er.receiver_id = ?) " +
                "AND er.status = 'ACCEPTED' " +
                "ORDER BY u.name";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);

            ResultSet rs =
                    ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                int partnerId =
                        rs.getInt("user_id");

                String partnerName =
                        rs.getString("name");

                String college =
                        rs.getString("college");

                // =========================
                // PARTNER CARD
                // =========================

                VBox partnerCard =
                        new VBox(14);

                partnerCard.setPadding(
                        new Insets(22)
                );

                partnerCard.setMaxWidth(
                        Double.MAX_VALUE
                );

                partnerCard.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 16px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 16px;" +
                        "-fx-border-width: 1px;"
                );

                // =========================
                // PARTNER HEADER
                // =========================

                HBox partnerHeader =
                        new HBox(14);

                partnerHeader.setAlignment(
                        Pos.CENTER_LEFT
                );

                Label avatar =
                        new Label(
                                getInitials(partnerName)
                        );

                avatar.setStyle(
                        "-fx-background-color: #EEF2FF;" +
                        "-fx-text-fill: #4F46E5;" +
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-alignment: center;" +
                        "-fx-min-width: 45px;" +
                        "-fx-min-height: 45px;" +
                        "-fx-background-radius: 23px;"
                );

                VBox partnerInfo =
                        new VBox(4);

                Label partnerLabel =
                        new Label(partnerName);

                partnerLabel.setStyle(
                        "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );

                Label collegeLabel =
                        new Label(
                                college == null ||
                                college.isBlank()
                                ? "SkillSwap Member"
                                : college
                        );

                collegeLabel.setStyle(
                        "-fx-font-size: 12px;" +
                        "-fx-text-fill: #6B7280;"
                );

                partnerInfo.getChildren().addAll(
                        partnerLabel,
                        collegeLabel
                );

                partnerHeader.getChildren().addAll(
                        avatar,
                        partnerInfo
                );

                // =========================
                // DIVIDER
                // =========================

                Region divider =
                        new Region();

                divider.setPrefHeight(1);

                divider.setStyle(
                        "-fx-background-color: #E5E7EB;"
                );

                // =========================
                // RATING
                // =========================

                Label ratingTitle =
                        new Label("Your rating");

                ratingTitle.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #374151;"
                );

                ComboBox<Integer> ratingBox =
                        new ComboBox<>();

                ratingBox.getItems().addAll(
                        1, 2, 3, 4, 5
                );

                ratingBox.setPromptText(
                        "Select rating (1 - 5)"
                );

                ratingBox.setPrefWidth(220);
                ratingBox.setPrefHeight(40);

                ratingBox.setStyle(
                        "-fx-background-color: #F9FAFB;" +
                        "-fx-border-color: #D1D5DB;" +
                        "-fx-border-radius: 9px;" +
                        "-fx-background-radius: 9px;"
                );

                // =========================
                // FEEDBACK
                // =========================

                Label feedbackTitle =
                        new Label("Feedback");

                feedbackTitle.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #374151;"
                );

                TextArea feedbackArea =
                        new TextArea();

                feedbackArea.setPromptText(
                        "Write something about your exchange experience..."
                );

                feedbackArea.setPrefRowCount(3);
                feedbackArea.setWrapText(true);

                feedbackArea.setStyle(
                        "-fx-background-color: #F9FAFB;" +
                        "-fx-border-color: #D1D5DB;" +
                        "-fx-border-radius: 9px;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-font-size: 13px;"
                );

                // =========================
                // SUBMIT BUTTON
                // =========================

                Button submitButton =
                        new Button("SUBMIT RATING");

                submitButton.setPrefHeight(40);
                submitButton.setPrefWidth(180);

                submitButton.setStyle(
                        "-fx-background-color: #4F46E5;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                );

                submitButton.setOnMouseEntered(event ->
                        submitButton.setStyle(
                                "-fx-background-color: #4338CA;" +
                                "-fx-text-fill: white;" +
                                "-fx-font-size: 12px;" +
                                "-fx-font-weight: bold;" +
                                "-fx-background-radius: 9px;" +
                                "-fx-cursor: hand;"
                        )
                );

                submitButton.setOnMouseExited(event ->
                        submitButton.setStyle(
                                "-fx-background-color: #4F46E5;" +
                                "-fx-text-fill: white;" +
                                "-fx-font-size: 12px;" +
                                "-fx-font-weight: bold;" +
                                "-fx-background-radius: 9px;" +
                                "-fx-cursor: hand;"
                        )
                );

                Label message =
                        new Label();

                message.setStyle(
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #16A34A;"
                );

                submitButton.setOnAction(event -> {

                    Integer rating =
                            ratingBox.getValue();

                    if (rating == null) {

                        message.setStyle(
                                "-fx-font-size: 12px;" +
                                "-fx-font-weight: bold;" +
                                "-fx-text-fill: #DC2626;"
                        );

                        message.setText(
                                "Please select a rating."
                        );

                        return;
                    }

                    saveRating(
                            userId,
                            partnerId,
                            rating,
                            feedbackArea.getText(),
                            message
                    );

                    submitButton.setDisable(true);
                    submitButton.setText(
                            "RATING SUBMITTED"
                    );
                });

                partnerCard.getChildren().addAll(
                        partnerHeader,
                        divider,
                        ratingTitle,
                        ratingBox,
                        feedbackTitle,
                        feedbackArea,
                        submitButton,
                        message
                );

                ratingList.getChildren().add(
                        partnerCard
                );
            }

            if (!found) {

                VBox emptyCard =
                        new VBox(10);

                emptyCard.setAlignment(
                        Pos.CENTER
                );

                emptyCard.setPadding(
                        new Insets(35)
                );

                emptyCard.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 16px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 16px;"
                );

                Label emptyTitle =
                        new Label(
                                "No exchanges to rate yet"
                        );

                emptyTitle.setStyle(
                        "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #374151;"
                );

                Label emptyText =
                        new Label(
                                "Once you have an accepted skill exchange, " +
                                "your partner will appear here."
                        );

                emptyText.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-text-fill: #6B7280;"
                );

                emptyCard.getChildren().addAll(
                        emptyTitle,
                        emptyText
                );

                ratingList.getChildren().add(
                        emptyCard
                );
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            Label error =
                    new Label(
                            "Could not load exchange partners."
                    );

            error.setStyle(
                    "-fx-text-fill: #DC2626;" +
                    "-fx-font-weight: bold;"
            );

            ratingList.getChildren().add(error);

            e.printStackTrace();
        }
    }

    // =========================================================
    // SAVE RATING
    // =========================================================

    private void saveRating(
            int giverId,
            int receiverId,
            int rating,
            String feedback,
            Label message) {

        String sql =
                "INSERT INTO ratings " +
                "(giver_id, receiver_id, rating, feedback) " +
                "VALUES (?, ?, ?, ?)";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, giverId);
            ps.setInt(2, receiverId);
            ps.setInt(3, rating);
            ps.setString(4, feedback);

            ps.executeUpdate();

            ps.close();
            con.close();

            message.setStyle(
                    "-fx-font-size: 12px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #16A34A;"
            );

            message.setText(
                    "✓ Rating submitted successfully!"
            );

        } catch (Exception e) {

            message.setStyle(
                    "-fx-font-size: 12px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: #DC2626;"
            );

            message.setText(
                    "Could not submit rating."
            );

            e.printStackTrace();
        }
    }

    // =========================================================
    // GET INITIALS
    // =========================================================

    private String getInitials(String name) {

        if (name == null || name.isBlank()) {
            return "U";
        }

        String[] parts =
                name.trim().split("\\s+");

        if (parts.length == 1) {

            return parts[0]
                    .substring(0, 1)
                    .toUpperCase();
        }

        return (
                parts[0].substring(0, 1) +
                parts[parts.length - 1]
                        .substring(0, 1)
        ).toUpperCase();
    }
}
package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MessagesController {

    // =========================================================
    // MESSAGES HOME PAGE
    // =========================================================

    public void showMessagesPage(Stage stage, int userId, String userName) {

        // -----------------------------------------------------
        // HEADER
        // -----------------------------------------------------

        Label logo = new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 40px;" +
                "-fx-min-height: 40px;" +
                "-fx-max-width: 40px;" +
                "-fx-max-height: 40px;"
        );

        Label title = new Label("Messages");

        title.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox header = new HBox(12, logo, title);

        header.setAlignment(Pos.CENTER_LEFT);

        header.setPadding(
                new Insets(18, 25, 18, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );

        // -----------------------------------------------------
        // BACK BUTTON
        // -----------------------------------------------------

        Button backButton =
                new Button("← DASHBOARD");

        backButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event -> {

            new DashboardController().showDashboard(
                    stage,
                    userId,
                    userName
            );

        });

        // -----------------------------------------------------
        // PAGE TITLE
        // -----------------------------------------------------

        Label heading =
                new Label("Your conversations");

        heading.setStyle(
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label info =
                new Label(
                        "Chat with students from your accepted skill exchanges."
                );

        info.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );

        Label sectionTitle =
                new Label("YOUR CONNECTIONS");

        sectionTitle.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #6B7280;"
        );

        // -----------------------------------------------------
        // CONTACT LIST
        // -----------------------------------------------------

        VBox peopleList = new VBox(14);

        peopleList.setPadding(new Insets(5));

        loadPeople(
                userId,
                peopleList,
                stage,
                userName
        );

        ScrollPane scrollPane =
                new ScrollPane(peopleList);

        scrollPane.setFitToWidth(true);

        scrollPane.setPrefHeight(480);

        scrollPane.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background: transparent;"
        );

        // -----------------------------------------------------
        // CONTENT
        // -----------------------------------------------------

        VBox content = new VBox(18);

        content.setPadding(new Insets(30));

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                backButton,
                heading,
                info,
                sectionTitle,
                scrollPane
        );

        // -----------------------------------------------------
        // ROOT
        // -----------------------------------------------------

        BorderPane root = new BorderPane();

        root.setTop(header);

        root.setCenter(content);

        Scene scene =
                new Scene(
                        root,
                        1000,
                        750
                );

        stage.setTitle(
                "SkillSwap - Messages"
        );

        stage.setScene(scene);

        stage.setMinWidth(850);

        stage.setMinHeight(650);

        stage.show();
    }

    // =========================================================
    // LOAD ACCEPTED CONNECTIONS
    // =========================================================

    private void loadPeople(
            int userId,
            VBox peopleList,
            Stage stage,
            String userName) {

        String sql =
                "SELECT DISTINCT " +
                "u.user_id, " +
                "u.name, " +
                "u.college " +
                "FROM exchange_requests er " +
                "JOIN users u " +
                "ON u.user_id = " +
                "CASE " +
                "WHEN er.sender_id = ? " +
                "THEN er.receiver_id " +
                "ELSE er.sender_id " +
                "END " +
                "WHERE (er.sender_id = ? " +
                "OR er.receiver_id = ?) " +
                "AND er.status = 'ACCEPTED' " +
                "ORDER BY u.name";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);
            ps.setInt(2, userId);
            ps.setInt(3, userId);

            ResultSet rs =
                    ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                int otherUserId =
                        rs.getInt("user_id");

                String otherUserName =
                        rs.getString("name");

                String college =
                        rs.getString("college");

                // -------------------------------------------------
                // PROFILE INITIAL
                // -------------------------------------------------

                Label profileIcon =
                        new Label(
                                getInitial(otherUserName)
                        );

                profileIcon.setStyle(
                        "-fx-background-color: #EEF2FF;" +
                        "-fx-text-fill: #4F46E5;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-alignment: center;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 52px;" +
                        "-fx-min-height: 52px;" +
                        "-fx-max-width: 52px;" +
                        "-fx-max-height: 52px;"
                );

                // -------------------------------------------------
                // NAME
                // -------------------------------------------------

                Label nameLabel =
                        new Label(otherUserName);

                nameLabel.setStyle(
                        "-fx-font-size: 17px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );

                // -------------------------------------------------
                // COLLEGE
                // -------------------------------------------------

                Label collegeLabel =
                        new Label(
                                college == null
                                        ? "College not provided"
                                        : college
                        );

                collegeLabel.setStyle(
                        "-fx-font-size: 12px;" +
                        "-fx-text-fill: #6B7280;"
                );

                VBox personInfo =
                        new VBox(
                                4,
                                nameLabel,
                                collegeLabel
                        );

                // -------------------------------------------------
                // PERSON SECTION
                // -------------------------------------------------

                HBox person =
                        new HBox(
                                14,
                                profileIcon,
                                personInfo
                        );

                person.setAlignment(
                        Pos.CENTER_LEFT
                );

                // -------------------------------------------------
                // CHAT BUTTON
                // -------------------------------------------------

                Button chatButton =
                        new Button("OPEN CHAT  →");

                chatButton.setPrefWidth(145);

                chatButton.setPrefHeight(38);

                chatButton.setStyle(
                        "-fx-background-color: #4F46E5;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;" +
                        "-fx-font-size: 11px;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-cursor: hand;"
                );

                // -------------------------------------------------
                // SPACER
                // -------------------------------------------------

                Region spacer = new Region();

                HBox.setHgrow(
                        spacer,
                        Priority.ALWAYS
                );

                HBox row =
                        new HBox(
                                person,
                                spacer,
                                chatButton
                        );

                row.setAlignment(
                        Pos.CENTER_LEFT
                );

                // -------------------------------------------------
                // CONTACT CARD
                // -------------------------------------------------

                VBox card =
                        new VBox(row);

                card.setPadding(
                        new Insets(18)
                );

                card.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 14px;"
                );

                chatButton.setOnAction(event -> {

                    showChatPage(
                            stage,
                            userId,
                            userName,
                            otherUserId,
                            otherUserName
                    );

                });

                peopleList
                        .getChildren()
                        .add(card);
            }

            // -------------------------------------------------
            // NO CONVERSATIONS
            // -------------------------------------------------

            if (!found) {

                Label emptyTitle =
                        new Label("No conversations yet");

                emptyTitle.setStyle(
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );

                Label emptyText =
                        new Label(
                                "Accept a skill exchange request " +
                                "to start chatting with another student."
                        );

                emptyText.setStyle(
                        "-fx-font-size: 14px;" +
                        "-fx-text-fill: #6B7280;"
                );

                VBox emptyBox =
                        new VBox(
                                8,
                                emptyTitle,
                                emptyText
                        );

                emptyBox.setAlignment(
                        Pos.CENTER
                );

                emptyBox.setPadding(
                        new Insets(60)
                );

                peopleList
                        .getChildren()
                        .add(emptyBox);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            peopleList
                    .getChildren()
                    .add(
                            new Label(
                                    "Could not load contacts."
                            )
                    );
        }
    }

    // =========================================================
    // CHAT PAGE
    // =========================================================

    private void showChatPage(
            Stage stage,
            int userId,
            String userName,
            int otherUserId,
            String otherUserName) {

        // -----------------------------------------------------
        // CHAT HEADER
        // -----------------------------------------------------

        Label profileIcon =
                new Label(
                        getInitial(otherUserName)
                );

        profileIcon.setStyle(
                "-fx-background-color: #EEF2FF;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 46px;" +
                "-fx-min-height: 46px;" +
                "-fx-max-width: 46px;" +
                "-fx-max-height: 46px;"
        );

        Label nameLabel =
                new Label(otherUserName);

        nameLabel.setStyle(
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label onlineLabel =
                new Label("SkillSwap connection");

        onlineLabel.setStyle(
                "-fx-font-size: 11px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox personInfo =
                new VBox(
                        3,
                        nameLabel,
                        onlineLabel
                );

        HBox chatHeader =
                new HBox(
                        12,
                        profileIcon,
                        personInfo
                );

        chatHeader.setAlignment(
                Pos.CENTER_LEFT
        );

        chatHeader.setPadding(
                new Insets(
                        15,
                        20,
                        15,
                        20
                )
        );

        chatHeader.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );

        // -----------------------------------------------------
        // MESSAGE AREA
        // -----------------------------------------------------

        VBox messageBox =
                new VBox(10);

        messageBox.setPadding(
                new Insets(20)
        );

        ScrollPane messageScroll =
                new ScrollPane(messageBox);

        messageScroll.setFitToWidth(true);

        messageScroll.setStyle(
                "-fx-background-color: #F3F4F6;" +
                "-fx-background: #F3F4F6;"
        );

        loadMessages(
                userId,
                otherUserId,
                messageBox
        );

        // -----------------------------------------------------
        // MESSAGE INPUT
        // -----------------------------------------------------

        TextField messageField =
                new TextField();

        messageField.setPromptText(
                "Write a message..."
        );

        messageField.setPrefHeight(42);

        HBox.setHgrow(
                messageField,
                Priority.ALWAYS
        );

        Button sendButton =
                new Button("SEND  →");

        sendButton.setPrefWidth(110);

        sendButton.setPrefHeight(42);

        sendButton.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );

        Label messageStatus =
                new Label();

        messageStatus.setStyle(
                "-fx-font-size: 12px;"
        );

        // -----------------------------------------------------
        // SEND MESSAGE ACTION
        // -----------------------------------------------------

        sendButton.setOnAction(event -> {

            String message =
                    messageField
                            .getText()
                            .trim();

            if (message.isEmpty()) {

                messageStatus.setText(
                        "Type a message first."
                );

                messageStatus.setStyle(
                        "-fx-text-fill: #DC2626;" +
                        "-fx-font-size: 12px;"
                );

                return;
            }

            boolean sent =
                    sendMessage(
                            userId,
                            otherUserId,
                            message
                    );

            if (sent) {

                messageField.clear();

                messageStatus.setText("");

                loadMessages(
                        userId,
                        otherUserId,
                        messageBox
                );

                messageScroll.setVvalue(1.0);

            } else {

                messageStatus.setText(
                        "Message could not be sent."
                );

                messageStatus.setStyle(
                        "-fx-text-fill: #DC2626;" +
                        "-fx-font-size: 12px;"
                );
            }
        });

        // -----------------------------------------------------
        // ENTER KEY TO SEND
        // -----------------------------------------------------

        messageField.setOnAction(event -> {
            sendButton.fire();
        });

        HBox inputRow =
                new HBox(
                        10,
                        messageField,
                        sendButton
                );

        inputRow.setAlignment(
                Pos.CENTER
        );

        inputRow.setPadding(
                new Insets(
                        12,
                        15,
                        8,
                        15
                )
        );

        inputRow.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 1 0 0 0;"
        );

        // -----------------------------------------------------
        // BACK BUTTON
        // -----------------------------------------------------

        Button backButton =
                new Button(
                        "← BACK TO MESSAGES"
                );

        backButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event -> {

            showMessagesPage(
                    stage,
                    userId,
                    userName
            );

        });

        HBox bottomArea =
                new HBox(
                        10,
                        backButton,
                        messageStatus
                );

        bottomArea.setAlignment(
                Pos.CENTER_LEFT
        );

        bottomArea.setPadding(
                new Insets(
                        0,
                        15,
                        10,
                        15
                )
        );

        bottomArea.setStyle(
                "-fx-background-color: white;"
        );

        // -----------------------------------------------------
        // ROOT
        // -----------------------------------------------------

        BorderPane root =
                new BorderPane();

        root.setTop(chatHeader);

        root.setCenter(messageScroll);

        root.setBottom(
                new VBox(
                        inputRow,
                        bottomArea
                )
        );

        Scene scene =
                new Scene(
                        root,
                        900,
                        700
                );

        stage.setTitle(
                "SkillSwap - Chat with " +
                otherUserName
        );

        stage.setScene(scene);

        stage.setMinWidth(750);

        stage.setMinHeight(600);

        stage.show();

        messageField.requestFocus();
    }

    // =========================================================
    // LOAD MESSAGES
    // =========================================================

    private void loadMessages(
            int userId,
            int otherUserId,
            VBox messageBox) {

        messageBox
                .getChildren()
                .clear();

        String sql =
                "SELECT sender_id, message, sent_at " +
                "FROM messages " +
                "WHERE " +
                "(sender_id = ? AND receiver_id = ?) " +
                "OR " +
                "(sender_id = ? AND receiver_id = ?) " +
                "ORDER BY sent_at";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);
            ps.setInt(2, otherUserId);
            ps.setInt(3, otherUserId);
            ps.setInt(4, userId);

            ResultSet rs =
                    ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                int senderId =
                        rs.getInt("sender_id");

                String message =
                        rs.getString("message");

                Label messageLabel =
                        new Label(message);

                messageLabel.setWrapText(true);

                messageLabel.setMaxWidth(450);

                messageLabel.setPadding(
                        new Insets(
                                10,
                                14,
                                10,
                                14
                        )
                );

                if (senderId == userId) {

                    // -----------------------------------------
                    // MY MESSAGE
                    // -----------------------------------------

                    messageLabel.setStyle(
                            "-fx-background-color: #4F46E5;" +
                            "-fx-text-fill: white;" +
                            "-fx-background-radius: 15px 15px 4px 15px;" +
                            "-fx-font-size: 14px;"
                    );

                    HBox bubble =
                            new HBox(messageLabel);

                    bubble.setAlignment(
                            Pos.CENTER_RIGHT
                    );

                    messageBox
                            .getChildren()
                            .add(bubble);

                } else {

                    // -----------------------------------------
                    // OTHER PERSON'S MESSAGE
                    // -----------------------------------------

                    messageLabel.setStyle(
                            "-fx-background-color: white;" +
                            "-fx-text-fill: #374151;" +
                            "-fx-background-radius: 15px 15px 15px 4px;" +
                            "-fx-border-color: #E5E7EB;" +
                            "-fx-border-radius: 15px;" +
                            "-fx-font-size: 14px;"
                    );

                    HBox bubble =
                            new HBox(messageLabel);

                    bubble.setAlignment(
                            Pos.CENTER_LEFT
                    );

                    messageBox
                            .getChildren()
                            .add(bubble);
                }
            }

            if (!found) {

                Label empty =
                        new Label(
                                "Start the conversation 👋"
                        );

                empty.setStyle(
                        "-fx-font-size: 16px;" +
                        "-fx-text-fill: #9CA3AF;"
                );

                VBox emptyBox =
                        new VBox(empty);

                emptyBox.setAlignment(
                        Pos.CENTER
                );

                emptyBox.setPadding(
                        new Insets(100)
                );

                messageBox
                        .getChildren()
                        .add(emptyBox);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

            messageBox
                    .getChildren()
                    .add(
                            new Label(
                                    "Could not load messages."
                            )
                    );
        }
    }

    // =========================================================
    // SEND MESSAGE
    // =========================================================

    private boolean sendMessage(
            int senderId,
            int receiverId,
            String message) {

        String sql =
                "INSERT INTO messages " +
                "(sender_id, receiver_id, message) " +
                "VALUES (?, ?, ?)";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, senderId);

            ps.setInt(2, receiverId);

            ps.setString(3, message);

            ps.executeUpdate();

            ps.close();
            con.close();

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    // =========================================================
    // GET INITIAL
    // =========================================================

    private String getInitial(String name) {

        if (name == null ||
                name.trim().isEmpty()) {

            return "S";
        }

        return name
                .trim()
                .substring(0, 1)
                .toUpperCase();
    }
}
package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class RegisterController {

    public void showRegisterPage(Stage stage) {

        // ==============================
        // LEFT BRANDING PANEL
        // ==============================

        Label logo = new Label("S");

        logo.setStyle(
                "-fx-background-color: white;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 34px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 70px;" +
                "-fx-min-height: 70px;" +
                "-fx-max-width: 70px;" +
                "-fx-max-height: 70px;"
        );

        Label brandName =
                new Label("SkillSwap");

        brandName.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 34px;" +
                "-fx-font-weight: bold;"
        );

        Label heading =
                new Label(
                        "Your skills have value."
                );

        heading.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 24px;" +
                "-fx-font-weight: bold;"
        );

        Label description =
                new Label(
                        "Join a community where students\n" +
                        "teach what they know and learn\n" +
                        "what they love."
                );

        description.setStyle(
                "-fx-text-fill: #E0E7FF;" +
                "-fx-font-size: 16px;" +
                "-fx-line-spacing: 7px;"
        );

        Label point1 =
                new Label("💡 Share your knowledge");

        Label point2 =
                new Label("🤝 Meet like-minded students");

        Label point3 =
                new Label("🚀 Build skills together");

        point1.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        point2.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        point3.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        VBox points =
                new VBox(
                        15,
                        point1,
                        point2,
                        point3
                );

        VBox leftPanel =
                new VBox(22);

        leftPanel.setAlignment(
                Pos.CENTER_LEFT
        );

        leftPanel.setPadding(
                new Insets(50)
        );

        leftPanel.setPrefWidth(430);

        leftPanel.setStyle(
                "-fx-background-color: " +
                "linear-gradient(to bottom right, " +
                "#4F46E5, #7C3AED);"
        );

        leftPanel.getChildren().addAll(
                logo,
                brandName,
                heading,
                description,
                points
        );


        // ==============================
        // RIGHT REGISTER PANEL
        // ==============================

        Label title =
                new Label("Create your account");

        title.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label subtitle =
                new Label(
                        "Start your SkillSwap journey today."
                );

        subtitle.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );


        // NAME

        Label nameLabel =
                new Label("Full name");

        nameLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        TextField nameField =
                new TextField();

        nameField.setPromptText(
                "Enter your full name"
        );

        styleTextField(nameField);


        // EMAIL

        Label emailLabel =
                new Label("Email address");

        emailLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        TextField emailField =
                new TextField();

        emailField.setPromptText(
                "Enter your email"
        );

        styleTextField(emailField);


        // PASSWORD

        Label passwordLabel =
                new Label("Password");

        passwordLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        PasswordField passwordField =
                new PasswordField();

        passwordField.setPromptText(
                "Create a password"
        );

        styleTextField(passwordField);


        // COLLEGE

        Label collegeLabel =
                new Label("College");

        collegeLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        TextField collegeField =
                new TextField();

        collegeField.setPromptText(
                "Enter your college"
        );

        styleTextField(collegeField);


        // BUTTON

        Button registerButton =
                new Button(
                        "CREATE ACCOUNT  →"
                );

        registerButton.setPrefHeight(45);
        registerButton.setMaxWidth(
                Double.MAX_VALUE
        );

        registerButton.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );


        Label existing =
                new Label(
                        "Already have an account?"
                );

        existing.setStyle(
                "-fx-text-fill: #6B7280;" +
                "-fx-font-size: 13px;"
        );


        Button loginButton =
                new Button("BACK TO LOGIN");

        loginButton.setPrefHeight(40);
        loginButton.setMaxWidth(
                Double.MAX_VALUE
        );

        loginButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-border-color: #4F46E5;" +
                "-fx-border-radius: 8px;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );


        Label message =
                new Label();

        message.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-text-fill: #DC2626;"
        );


        // ==============================
        // REGISTER DATABASE ACTION
        // ==============================

        registerButton.setOnAction(event -> {

            String name =
                    nameField.getText().trim();

            String email =
                    emailField.getText().trim();

            String password =
                    passwordField.getText();

            String college =
                    collegeField.getText().trim();


            if (name.isEmpty()
                    || email.isEmpty()
                    || password.isEmpty()) {

                message.setText(
                        "Please fill all required fields."
                );

                return;
            }


            String sql =
                    "INSERT INTO users " +
                    "(name, email, password, college) " +
                    "VALUES (?, ?, ?, ?)";


            try {

                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, password);
                ps.setString(4, college);


                ps.executeUpdate();

                ps.close();
                con.close();


                message.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-text-fill: #16A34A;"
                );

                message.setText(
                        "Account created successfully!"
                );


                nameField.clear();
                emailField.clear();
                passwordField.clear();
                collegeField.clear();


            } catch (Exception e) {

                message.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-text-fill: #DC2626;"
                );

                message.setText(
                        "Email may already be registered."
                );

                e.printStackTrace();
            }
        });


        loginButton.setOnAction(event -> {

            new LoginController()
                    .showLoginPage(stage);
        });


        // ==============================
        // REGISTER CARD
        // ==============================

        VBox registerCard =
                new VBox(10);

        registerCard.setPadding(
                new Insets(40)
        );

        registerCard.setPrefWidth(470);
        registerCard.setMaxWidth(470);

        registerCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 16px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 16px;"
        );

        registerCard.getChildren().addAll(

                title,
                subtitle,

                createSpacer(8),

                nameLabel,
                nameField,

                emailLabel,
                emailField,

                passwordLabel,
                passwordField,

                collegeLabel,
                collegeField,

                createSpacer(5),

                registerButton,

                createSpacer(3),

                existing,
                loginButton,

                message
        );


        VBox rightPanel =
                new VBox();

        rightPanel.setAlignment(
                Pos.CENTER
        );

        rightPanel.setPrefWidth(570);

        rightPanel.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        rightPanel.getChildren()
                .add(registerCard);


        // ==============================
        // MAIN LAYOUT
        // ==============================

        HBox mainLayout =
                new HBox(
                        leftPanel,
                        rightPanel
                );


        Scene scene =
                new Scene(
                        mainLayout,
                        1000,
                        700
                );


        stage.setTitle(
                "SkillSwap - Create Account"
        );

        stage.setScene(scene);

        stage.setMinWidth(900);
        stage.setMinHeight(650);

        stage.show();
    }


    // ==============================
    // TEXT FIELD STYLE
    // ==============================

    private void styleTextField(
            TextField field) {

        field.setPrefHeight(45);

        field.setStyle(
                "-fx-background-color: #F9FAFB;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 8px;" +
                "-fx-background-radius: 8px;" +
                "-fx-padding: 0 14px;" +
                "-fx-font-size: 14px;"
        );
    }


    // ==============================
    // SPACER
    // ==============================

    private Region createSpacer(
            double height) {

        Region spacer =
                new Region();

        spacer.setMinHeight(height);

        return spacer;
    }
}
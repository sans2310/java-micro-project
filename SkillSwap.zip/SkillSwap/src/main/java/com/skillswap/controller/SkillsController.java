package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SkillsController {

    public void showSkillsPage(
            Stage stage,
            int userId,
            String userName) {

        // ==========================================
        // HEADER
        // ==========================================

        Label logo =
                new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 40px;" +
                "-fx-min-height: 40px;" +
                "-fx-max-width: 40px;" +
                "-fx-max-height: 40px;"
        );

        Label title =
                new Label("My Skills");

        title.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox header =
                new HBox(
                        12,
                        logo,
                        title
                );

        header.setAlignment(
                Pos.CENTER_LEFT
        );

        header.setPadding(
                new Insets(18, 25, 18, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );


        // ==========================================
        // INTRODUCTION
        // ==========================================

        Label heading =
                new Label(
                        "Manage your skills"
                );

        heading.setStyle(
                "-fx-font-size: 27px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label description =
                new Label(
                        "Tell the community what you can teach " +
                        "and what you want to learn."
                );

        description.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );


        // ==========================================
        // TEACHING SKILLS CARD
        // ==========================================

        Label teachTitle =
                new Label("I CAN TEACH");

        teachTitle.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #4F46E5;"
        );

        VBox teachList =
                new VBox(10);

        teachList.setPadding(
                new Insets(5)
        );

        loadUserSkills(
                userId,
                teachList,
                true
        );


        VBox teachCard =
                new VBox(
                        15,
                        teachTitle,
                        teachList
                );

        teachCard.setPadding(
                new Insets(20)
        );

        teachCard.setPrefWidth(360);

        teachCard.setMinHeight(220);

        teachCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 14px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 14px;"
        );


        // ==========================================
        // LEARNING SKILLS CARD
        // ==========================================

        Label learnTitle =
                new Label("I WANT TO LEARN");

        learnTitle.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #7C3AED;"
        );

        VBox learnList =
                new VBox(10);

        learnList.setPadding(
                new Insets(5)
        );

        loadUserSkills(
                userId,
                learnList,
                false
        );


        VBox learnCard =
                new VBox(
                        15,
                        learnTitle,
                        learnList
                );

        learnCard.setPadding(
                new Insets(20)
        );

        learnCard.setPrefWidth(360);

        learnCard.setMinHeight(220);

        learnCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 14px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 14px;"
        );


        HBox skillCards =
                new HBox(
                        20,
                        teachCard,
                        learnCard
                );

        skillCards.setAlignment(
                Pos.CENTER
        );


        // ==========================================
        // ADD SKILL SECTION
        // ==========================================

        Label addTitle =
                new Label(
                        "+ Add a skill"
                );

        addTitle.setStyle(
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );


        Label skillLabel =
                new Label("Skill");

        skillLabel.setStyle(
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );


        ComboBox<String> skillComboBox =
                new ComboBox<>();

        skillComboBox.setPromptText(
                "Select a skill"
        );

        skillComboBox.setPrefWidth(260);

        skillComboBox.setPrefHeight(40);

        loadSkills(skillComboBox);


        Label typeLabel =
                new Label("I want to");

        typeLabel.setStyle(
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );


        ComboBox<String> typeComboBox =
                new ComboBox<>();

        typeComboBox.getItems().addAll(
                "TEACH",
                "LEARN"
        );

        typeComboBox.setPromptText(
                "Choose TEACH or LEARN"
        );

        typeComboBox.setPrefWidth(260);

        typeComboBox.setPrefHeight(40);


        Label levelLabel =
                new Label("Skill level");

        levelLabel.setStyle(
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );


        ComboBox<String> levelComboBox =
                new ComboBox<>();

        levelComboBox.getItems().addAll(
                "Beginner",
                "Intermediate",
                "Advanced"
        );

        levelComboBox.setPromptText(
                "Select level"
        );

        levelComboBox.setPrefWidth(260);

        levelComboBox.setPrefHeight(40);


        Button addButton =
                new Button("ADD SKILL  +");

        addButton.setPrefWidth(260);

        addButton.setPrefHeight(42);

        addButton.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );


        Label message =
                new Label();


        // ==========================================
        // ADD SKILL ACTION
        // ==========================================

        addButton.setOnAction(event -> {

            String skill =
                    skillComboBox.getValue();

            String type =
                    typeComboBox.getValue();

            String level =
                    levelComboBox.getValue();


            if (skill == null
                    || type == null
                    || level == null) {

                message.setStyle(
                        "-fx-text-fill: #DC2626;"
                );

                message.setText(
                        "Please select skill, type and level."
                );

                return;
            }


            saveSkill(
                    userId,
                    skill,
                    type,
                    level,
                    message
            );


            teachList.getChildren().clear();

            learnList.getChildren().clear();


            loadUserSkills(
                    userId,
                    teachList,
                    true
            );

            loadUserSkills(
                    userId,
                    learnList,
                    false
            );


            skillComboBox.setValue(null);

            typeComboBox.setValue(null);

            levelComboBox.setValue(null);
        });


        // ==========================================
        // FORM
        // ==========================================

        VBox form =
                new VBox(10);

        form.setPadding(
                new Insets(20)
        );

        form.setMaxWidth(850);

        form.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 14px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 14px;"
        );

        form.getChildren().addAll(
                addTitle,
                skillLabel,
                skillComboBox,
                typeLabel,
                typeComboBox,
                levelLabel,
                levelComboBox,
                addButton,
                message
        );


        // ==========================================
        // BACK BUTTON
        // ==========================================

        Button backButton =
                new Button("← BACK TO DASHBOARD");

        backButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event -> {

            new DashboardController()
                    .showDashboard(
                            stage,
                            userId,
                            userName
                    );
        });


        // ==========================================
        // CONTENT
        // ==========================================

        VBox content =
                new VBox(25);

        content.setPadding(
                new Insets(30)
        );

        content.setAlignment(
                Pos.TOP_CENTER
        );

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                backButton,
                heading,
                description,
                skillCards,
                form
        );


        // ==========================================
        // ROOT
        // ==========================================

        BorderPane root =
                new BorderPane();

        root.setTop(header);

        root.setCenter(content);


        Scene scene =
                new Scene(
                        root,
                        1000,
                        750
                );


        stage.setTitle(
                "SkillSwap - My Skills"
        );

        stage.setScene(scene);

        stage.setMinWidth(900);

        stage.setMinHeight(700);

        stage.show();
    }


    // ==========================================
    // LOAD AVAILABLE SKILLS
    // ==========================================

    private void loadSkills(
            ComboBox<String> comboBox) {

        String sql =
                "SELECT skill_name " +
                "FROM skills " +
                "ORDER BY skill_name";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs =
                    ps.executeQuery();

            while (rs.next()) {

                comboBox.getItems().add(
                        rs.getString("skill_name")
                );
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    // ==========================================
    // LOAD USER SKILLS
    // ==========================================

    private void loadUserSkills(
            int userId,
            VBox list,
            boolean teaching) {

        String type =
                teaching
                        ? "TEACH"
                        : "LEARN";


        String sql =
                "SELECT s.skill_name, us.level " +
                "FROM user_skills us " +
                "JOIN skills s " +
                "ON us.skill_id = s.skill_id " +
                "WHERE us.user_id = ? " +
                "AND us.skill_type = ? " +
                "ORDER BY s.skill_name";


        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);

            ps.setString(2, type);

            ResultSet rs =
                    ps.executeQuery();

            boolean found = false;

            while (rs.next()) {

                found = true;

                String skill =
                        rs.getString("skill_name");

                String level =
                        rs.getString("level");


                Label skillLabel =
                        new Label(
                                "• " +
                                skill +
                                "   —   " +
                                level
                        );

                skillLabel.setStyle(
                        "-fx-font-size: 14px;" +
                        "-fx-text-fill: #374151;"
                );

                list.getChildren()
                        .add(skillLabel);
            }


            if (!found) {

                Label empty =
                        new Label(
                                teaching
                                        ? "No teaching skills added yet."
                                        : "No learning skills added yet."
                        );

                empty.setStyle(
                        "-fx-text-fill: #9CA3AF;" +
                        "-fx-font-size: 13px;"
                );

                list.getChildren()
                        .add(empty);
            }


            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }


    // ==========================================
    // SAVE SKILL
    // ==========================================

    private void saveSkill(
            int userId,
            String skill,
            String type,
            String level,
            Label message) {

        String sql =
                "INSERT INTO user_skills " +
                "(user_id, skill_id, skill_type, level) " +
                "SELECT ?, skill_id, ?, ? " +
                "FROM skills " +
                "WHERE skill_name = ? " +
                "ON CONFLICT " +
                "(user_id, skill_id, skill_type) " +
                "DO UPDATE SET " +
                "level = EXCLUDED.level";


        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);

            ps.setString(2, type);

            ps.setString(3, level);

            ps.setString(4, skill);


            ps.executeUpdate();

            ps.close();

            con.close();


            message.setStyle(
                    "-fx-text-fill: #16A34A;"
            );

            message.setText(
                    "Skill added successfully!"
            );

        } catch (Exception e) {

            message.setStyle(
                    "-fx-text-fill: #DC2626;"
            );

            message.setText(
                    "Could not save skill."
            );

            e.printStackTrace();
        }
    }
}
package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DashboardController {

    public void showDashboard(Stage stage, int userId, String userName) {

        // =====================================================
        // DATABASE COUNTS
        // =====================================================

        int skillCount = getSkillCount(userId);
        int matchCount = getMatchCount(userId);
        int requestCount = getRequestCount(userId);

        // =====================================================
        // HEADER
        // =====================================================

        Label logo = new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 21px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 12px;" +
                "-fx-min-width: 42px;" +
                "-fx-min-height: 42px;" +
                "-fx-max-width: 42px;" +
                "-fx-max-height: 42px;"
        );

        Label appName = new Label("SkillSwap");

        appName.setStyle(
                "-fx-font-size: 23px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox branding = new HBox(
                10,
                logo,
                appName
        );

        branding.setAlignment(Pos.CENTER_LEFT);

        Label userLabel =
                new Label("Welcome, " + userName);

        userLabel.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        Button logoutButton =
                new Button("Logout");

        logoutButton.setPrefHeight(38);

        logoutButton.setStyle(
                "-fx-background-color: #FEE2E2;" +
                "-fx-text-fill: #DC2626;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 9px;" +
                "-fx-padding: 0 18px;" +
                "-fx-cursor: hand;"
        );

        logoutButton.setOnAction(event ->
                new LoginController().showLoginPage(stage)
        );

        Region headerSpacer =
                new Region();

        HBox.setHgrow(
                headerSpacer,
                Priority.ALWAYS
        );

        HBox header =
                new HBox(
                        15,
                        branding,
                        headerSpacer,
                        userLabel,
                        logoutButton
                );

        header.setAlignment(Pos.CENTER_LEFT);

        header.setPadding(
                new Insets(15, 25, 15, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );

        // =====================================================
        // SIDEBAR
        // =====================================================

        Label sideLogo =
                new Label("S");

        sideLogo.setStyle(
                "-fx-background-color: #6366F1;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 10px;" +
                "-fx-min-width: 36px;" +
                "-fx-min-height: 36px;" +
                "-fx-max-width: 36px;" +
                "-fx-max-height: 36px;"
        );

        Label sideTitle =
                new Label("SkillSwap");

        sideTitle.setStyle(
                "-fx-font-size: 19px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: white;"
        );

        HBox sideBrand =
                new HBox(
                        10,
                        sideLogo,
                        sideTitle
                );

        sideBrand.setAlignment(
                Pos.CENTER_LEFT
        );

        Label menuTitle =
                new Label("MAIN MENU");

        menuTitle.setStyle(
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #9CA3AF;"
        );

        // =====================================================
        // SIDEBAR BUTTONS
        // ONLY HOME, PROFILE AND REQUESTS
        // =====================================================

        Button homeButton =
                createMenuButton(
                        "⌂",
                        "Home"
                );

        Button profileButton =
                createMenuButton(
                        "◉",
                        "My Profile"
                );

        Button requestsButton =
                createMenuButton(
                        "✉",
                        "Requests",
                        requestCount
                );

        VBox sidebar =
                new VBox(8);

        sidebar.setPadding(
                new Insets(25, 14, 25, 14)
        );

        sidebar.setPrefWidth(220);

        sidebar.setStyle(
                "-fx-background-color: #111827;"
        );

        Region sideSpacer =
                new Region();

        VBox.setVgrow(
                sideSpacer,
                Priority.ALWAYS
        );

        Label bottomText =
                new Label("Learn • Teach • Connect");

        bottomText.setStyle(
                "-fx-text-fill: #6B7280;" +
                "-fx-font-size: 11px;"
        );

        sidebar.getChildren().addAll(
                sideBrand,
                menuTitle,
                homeButton,
                profileButton,
                requestsButton,
                sideSpacer,
                bottomText
        );

        // =====================================================
        // WELCOME AREA
        // =====================================================

        Label welcome =
                new Label(
                        "Good to see you, " +
                        userName +
                        " 👋"
                );

        welcome.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label subtitle =
                new Label(
                        "Exchange knowledge, discover new skills and connect with students."
                );

        subtitle.setStyle(
                "-fx-font-size: 15px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox welcomeBox =
                new VBox(
                        7,
                        welcome,
                        subtitle
                );

        // =====================================================
        // STAT CARDS
        // =====================================================

        VBox skillsCard =
                createStatCard(
                        "SKILLS",
                        String.valueOf(skillCount),
                        "Skills added",
                        "⚙"
                );

        VBox matchesCard =
                createStatCard(
                        "MATCHES",
                        String.valueOf(matchCount),
                        "Students matched",
                        "⌕"
                );

        VBox requestsCard =
                createStatCard(
                        "REQUESTS",
                        String.valueOf(requestCount),
                        "Pending requests",
                        "✉"
                );

        GridPane statsGrid =
                new GridPane();

        statsGrid.setHgap(18);
        statsGrid.setVgap(18);

        statsGrid.add(
                skillsCard,
                0,
                0
        );

        statsGrid.add(
                matchesCard,
                1,
                0
        );

        statsGrid.add(
                requestsCard,
                2,
                0
        );

        // =====================================================
        // QUICK ACTIONS TITLE
        // =====================================================

        Label quickTitle =
                new Label(
                        "What would you like to do?"
                );

        quickTitle.setStyle(
                "-fx-font-size: 21px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        // =====================================================
        // QUICK ACTION BUTTONS
        // =====================================================

        Button findButton =
                createActionButton(
                        "⌕",
                        "Find Matches",
                        "Discover students who can teach you"
                );

        Button messageButton =
                createActionButton(
                        "●",
                        "Messages",
                        "Continue your conversations"
                );

        Button skillButton =
                createActionButton(
                        "⚙",
                        "My Skills",
                        "Manage the skills you teach and learn"
                );

        Button ratingButton =
                createActionButton(
                        "★",
                        "Ratings",
                        "Give feedback for your exchanges"
                );

        GridPane actionGrid =
                new GridPane();

        actionGrid.setHgap(18);
        actionGrid.setVgap(18);

        actionGrid.add(
                findButton,
                0,
                0
        );

        actionGrid.add(
                messageButton,
                1,
                0
        );

        actionGrid.add(
                skillButton,
                0,
                1
        );

        actionGrid.add(
                ratingButton,
                1,
                1
        );

        // =====================================================
        // SIDEBAR BUTTON ACTIONS
        // =====================================================

        homeButton.setOnAction(event -> {

            showDashboard(
                    stage,
                    userId,
                    userName
            );

        });

        profileButton.setOnAction(event -> {

            new ProfileController()
                    .showProfilePage(
                            stage,
                            userId,
                            userName
                    );

        });

        requestsButton.setOnAction(event -> {

            new RequestsController()
                    .showRequestsPage(
                            stage,
                            userId,
                            userName
                    );

        });

        // =====================================================
        // QUICK ACTION BUTTON ACTIONS
        // =====================================================

        findButton.setOnAction(event -> {

            new MatchesController()
                    .showMatchesPage(
                            stage,
                            userId,
                            userName
                    );

        });

        messageButton.setOnAction(event -> {

            new MessagesController()
                    .showMessagesPage(
                            stage,
                            userId,
                            userName
                    );

        });

        skillButton.setOnAction(event -> {

            new SkillsController()
                    .showSkillsPage(
                            stage,
                            userId,
                            userName
                    );

        });

        ratingButton.setOnAction(event -> {

            new RatingController()
                    .showRatingPage(
                            stage,
                            userId,
                            userName
                    );

        });

        // =====================================================
        // MAIN CONTENT
        // =====================================================

        VBox content =
                new VBox(27);

        content.setPadding(
                new Insets(
                        35,
                        40,
                        35,
                        40
                )
        );

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                welcomeBox,
                statsGrid,
                quickTitle,
                actionGrid
        );

        // =====================================================
        // ROOT
        // =====================================================

        BorderPane root =
                new BorderPane();

        root.setTop(header);
        root.setLeft(sidebar);
        root.setCenter(content);

        Scene scene =
                new Scene(
                        root,
                        1150,
                        720
                );

        stage.setTitle(
                "SkillSwap - Dashboard"
        );

        stage.setScene(scene);

        stage.setMinWidth(1000);
        stage.setMinHeight(650);

        stage.show();
    }

    // =========================================================
    // SIDEBAR BUTTON WITHOUT BADGE
    // =========================================================

    private Button createMenuButton(
            String icon,
            String text) {

        return createMenuButton(
                icon,
                text,
                0
        );
    }

    // =========================================================
    // SIDEBAR BUTTON WITH BADGE
    // =========================================================

    private Button createMenuButton(
            String icon,
            String text,
            int badgeCount) {

        Label iconLabel =
                new Label(icon);

        iconLabel.setStyle(
                "-fx-text-fill: #A5B4FC;" +
                "-fx-font-size: 16px;"
        );

        Label textLabel =
                new Label(text);

        textLabel.setStyle(
                "-fx-text-fill: #D1D5DB;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;"
        );

        HBox content =
                new HBox(
                        13,
                        iconLabel,
                        textLabel
                );

        content.setAlignment(
                Pos.CENTER_LEFT
        );

        // Prevent graphic from consuming mouse clicks.
        content.setMouseTransparent(true);

        // =====================================================
        // BADGE
        // =====================================================

        if (badgeCount > 0) {

            Region badgeSpacer =
                    new Region();

            HBox.setHgrow(
                    badgeSpacer,
                    Priority.ALWAYS
            );

            Label badge =
                    new Label(
                            badgeCount > 99
                                    ? "99+"
                                    : String.valueOf(badgeCount)
                    );

            badge.setStyle(
                    "-fx-background-color: #EF4444;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-size: 10px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-alignment: center;" +
                    "-fx-background-radius: 12px;" +
                    "-fx-min-width: 22px;" +
                    "-fx-min-height: 22px;" +
                    "-fx-padding: 0 6px;"
            );

            content.getChildren().addAll(
                    badgeSpacer,
                    badge
            );
        }

        Button button =
                new Button();

        button.setGraphic(content);

        button.setMaxWidth(
                Double.MAX_VALUE
        );

        button.setPrefHeight(46);

        button.setAlignment(
                Pos.CENTER_LEFT
        );

        button.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background-radius: 9px;" +
                "-fx-cursor: hand;"
        );

        button.setOnMouseEntered(event ->

                button.setStyle(
                        "-fx-background-color: #1F2937;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )

        );

        button.setOnMouseExited(event ->

                button.setStyle(
                        "-fx-background-color: transparent;" +
                        "-fx-background-radius: 9px;" +
                        "-fx-cursor: hand;"
                )

        );

        return button;
    }

    // =========================================================
    // STAT CARD
    // =========================================================

    private VBox createStatCard(
            String title,
            String number,
            String description,
            String icon) {

        Label iconLabel =
                new Label(icon);

        iconLabel.setStyle(
                "-fx-background-color: #EEF2FF;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 10px;" +
                "-fx-min-width: 42px;" +
                "-fx-min-height: 42px;" +
                "-fx-max-width: 42px;" +
                "-fx-max-height: 42px;"
        );

        Label titleLabel =
                new Label(title);

        titleLabel.setStyle(
                "-fx-font-size: 11px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #6B7280;"
        );

        Label numberLabel =
                new Label(number);

        numberLabel.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label descriptionLabel =
                new Label(description);

        descriptionLabel.setStyle(
                "-fx-font-size: 12px;" +
                "-fx-text-fill: #9CA3AF;"
        );

        VBox card =
                new VBox(
                        7,
                        iconLabel,
                        titleLabel,
                        numberLabel,
                        descriptionLabel
                );

        card.setPadding(
                new Insets(20)
        );

        card.setPrefWidth(230);
        card.setPrefHeight(155);

        card.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 16px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 16px;"
        );

        return card;
    }

    // =========================================================
    // QUICK ACTION BUTTON
    // =========================================================

    private Button createActionButton(
            String icon,
            String title,
            String description) {

        Label iconLabel =
                new Label(icon);

        iconLabel.setStyle(
                "-fx-background-color: #EEF2FF;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 20px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 10px;" +
                "-fx-min-width: 42px;" +
                "-fx-min-height: 42px;" +
                "-fx-max-width: 42px;" +
                "-fx-max-height: 42px;"
        );

        Label titleLabel =
                new Label(title);

        titleLabel.setStyle(
                "-fx-font-size: 15px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label descriptionLabel =
                new Label(description);

        descriptionLabel.setStyle(
                "-fx-font-size: 12px;" +
                "-fx-text-fill: #6B7280;"
        );

        VBox textBox =
                new VBox(
                        4,
                        titleLabel,
                        descriptionLabel
                );

        HBox content =
                new HBox(
                        15,
                        iconLabel,
                        textBox
                );

        content.setAlignment(
                Pos.CENTER_LEFT
        );

        // Prevent graphic from consuming mouse clicks.
        content.setMouseTransparent(true);

        Button button =
                new Button();

        button.setGraphic(content);

        button.setPrefSize(
                365,
                95
        );

        button.setAlignment(
                Pos.CENTER_LEFT
        );

        button.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 14px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 14px;" +
                "-fx-padding: 15px;" +
                "-fx-cursor: hand;"
        );

        button.setOnMouseEntered(event ->

                button.setStyle(
                        "-fx-background-color: #FAFAFF;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: #A5B4FC;" +
                        "-fx-border-radius: 14px;" +
                        "-fx-padding: 15px;" +
                        "-fx-cursor: hand;"
                )

        );

        button.setOnMouseExited(event ->

                button.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 14px;" +
                        "-fx-padding: 15px;" +
                        "-fx-cursor: hand;"
                )

        );

        return button;
    }

    // =========================================================
    // DATABASE - SKILL COUNT
    // =========================================================

    private int getSkillCount(int userId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM user_skills " +
                "WHERE user_id = ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(
                    1,
                    userId
            );

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                int count =
                        rs.getInt(1);

                rs.close();
                ps.close();
                con.close();

                return count;
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return 0;
    }

    // =========================================================
    // DATABASE - MATCH COUNT
    // =========================================================

    private int getMatchCount(int userId) {

        String sql =
                "SELECT COUNT(DISTINCT us.user_id) " +
                "FROM user_skills myskill " +
                "JOIN user_skills us " +
                "ON us.skill_id = myskill.skill_id " +
                "AND us.skill_type = 'TEACH' " +
                "WHERE myskill.user_id = ? " +
                "AND myskill.skill_type = 'LEARN' " +
                "AND us.user_id <> ?";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(
                    1,
                    userId
            );

            ps.setInt(
                    2,
                    userId
            );

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                int count =
                        rs.getInt(1);

                rs.close();
                ps.close();
                con.close();

                return count;
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return 0;
    }

    // =========================================================
    // DATABASE - REQUEST COUNT
    // =========================================================

    private int getRequestCount(int userId) {

        String sql =
                "SELECT COUNT(*) " +
                "FROM exchange_requests " +
                "WHERE receiver_id = ? " +
                "AND status = 'PENDING'";

        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(
                    1,
                    userId
            );

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                int count =
                        rs.getInt(1);

                rs.close();
                ps.close();
                con.close();

                return count;
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return 0;
    }
}
package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MatchesController {

    public void showMatchesPage(
            Stage stage,
            int userId,
            String userName) {

        // ==========================================
        // HEADER
        // ==========================================

        Label logo =
                new Label("S");

        logo.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 18px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 40px;" +
                "-fx-min-height: 40px;" +
                "-fx-max-width: 40px;" +
                "-fx-max-height: 40px;"
        );

        Label title =
                new Label("Find Matches");

        title.setStyle(
                "-fx-font-size: 22px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        HBox header =
                new HBox(
                        12,
                        logo,
                        title
                );

        header.setAlignment(
                Pos.CENTER_LEFT
        );

        header.setPadding(
                new Insets(18, 25, 18, 25)
        );

        header.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-width: 0 0 1 0;"
        );


        // ==========================================
        // BACK BUTTON
        // ==========================================

        Button backButton =
                new Button("← DASHBOARD");

        backButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;"
        );

        backButton.setOnAction(event -> {

            new DashboardController()
                    .showDashboard(
                            stage,
                            userId,
                            userName
                    );
        });


        // ==========================================
        // PAGE TITLE
        // ==========================================

        Label heading =
                new Label(
                        "Find your skill partners"
                );

        heading.setStyle(
                "-fx-font-size: 28px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label description =
                new Label(
                        "Connect with students who can teach " +
                        "the skills you want to learn."
                );

        description.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );


        Label sectionTitle =
                new Label("YOUR MATCHES");

        sectionTitle.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #6B7280;"
        );


        // ==========================================
        // MATCH LIST
        // ==========================================

        VBox matchesList =
                new VBox(18);

        matchesList.setPadding(
                new Insets(5)
        );

        loadMatches(
                userId,
                matchesList
        );


        ScrollPane scrollPane =
                new ScrollPane(
                        matchesList
                );

        scrollPane.setFitToWidth(true);

        scrollPane.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-background: transparent;"
        );

        scrollPane.setPrefHeight(450);


        // ==========================================
        // CONTENT
        // ==========================================

        VBox content =
                new VBox(18);

        content.setPadding(
                new Insets(30)
        );

        content.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        content.getChildren().addAll(
                backButton,
                heading,
                description,
                sectionTitle,
                scrollPane
        );


        BorderPane root =
                new BorderPane();

        root.setTop(header);

        root.setCenter(content);


        Scene scene =
                new Scene(
                        root,
                        1000,
                        750
                );


        stage.setTitle(
                "SkillSwap - Find Matches"
        );

        stage.setScene(scene);

        stage.setMinWidth(850);

        stage.setMinHeight(650);

        stage.show();
    }


    // ==========================================
    // LOAD MATCHES
    // ==========================================

    private void loadMatches(
            int userId,
            VBox matchesList) {

        String sql =
                "SELECT DISTINCT " +
                "u.user_id, " +
                "u.name, " +
                "u.college, " +
                "s.skill_name, " +
                "us.level " +
                "FROM user_skills myskill " +
                "JOIN skills wanted " +
                "ON myskill.skill_id = wanted.skill_id " +
                "JOIN user_skills us " +
                "ON us.skill_id = myskill.skill_id " +
                "AND us.skill_type = 'TEACH' " +
                "JOIN users u " +
                "ON u.user_id = us.user_id " +
                "JOIN skills s " +
                "ON s.skill_id = us.skill_id " +
                "WHERE myskill.user_id = ? " +
                "AND myskill.skill_type = 'LEARN' " +
                "AND us.user_id <> ? " +
                "ORDER BY u.name";


        try {

            Connection con =
                    DatabaseConnection.getConnection();

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, userId);

            ps.setInt(2, userId);

            ResultSet rs =
                    ps.executeQuery();


            boolean found = false;


            while (rs.next()) {

                found = true;


                int matchedUserId =
                        rs.getInt("user_id");

                String name =
                        rs.getString("name");

                String college =
                        rs.getString("college");

                String skill =
                        rs.getString("skill_name");

                String level =
                        rs.getString("level");


                // ==================================
                // PROFILE ICON
                // ==================================

                Label profileIcon =
                        new Label(
                                getInitial(name)
                        );

                profileIcon.setStyle(
                        "-fx-background-color: #EEF2FF;" +
                        "-fx-text-fill: #4F46E5;" +
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-alignment: center;" +
                        "-fx-background-radius: 50%;" +
                        "-fx-min-width: 50px;" +
                        "-fx-min-height: 50px;" +
                        "-fx-max-width: 50px;" +
                        "-fx-max-height: 50px;"
                );


                // ==================================
                // NAME
                // ==================================

                Label nameLabel =
                        new Label(name);

                nameLabel.setStyle(
                        "-fx-font-size: 18px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );


                Label collegeLabel =
                        new Label(
                                college == null
                                        ? "College not provided"
                                        : college
                        );

                collegeLabel.setStyle(
                        "-fx-font-size: 13px;" +
                        "-fx-text-fill: #6B7280;"
                );


                VBox personInfo =
                        new VBox(
                                4,
                                nameLabel,
                                collegeLabel
                        );


                HBox personHeader =
                        new HBox(
                                12,
                                profileIcon,
                                personInfo
                        );

                personHeader.setAlignment(
                        Pos.CENTER_LEFT
                );


                // ==================================
                // SKILL INFORMATION
                // ==================================

                Label canTeach =
                        new Label("CAN TEACH");

                canTeach.setStyle(
                        "-fx-font-size: 10px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #9CA3AF;"
                );


                Label skillLabel =
                        new Label(skill);

                skillLabel.setStyle(
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #4F46E5;"
                );


                Label levelLabel =
                        new Label(
                                "Level: " + level
                        );

                levelLabel.setStyle(
                        "-fx-font-size: 12px;" +
                        "-fx-text-fill: #6B7280;"
                );


                VBox skillInfo =
                        new VBox(
                                5,
                                canTeach,
                                skillLabel,
                                levelLabel
                        );


                // ==================================
                // REQUEST BUTTON
                // ==================================

                Button requestButton =
                        new Button(
                                "SEND REQUEST  →"
                        );

                requestButton.setPrefWidth(
                        170
                );

                requestButton.setPrefHeight(
                        42
                );

                requestButton.setStyle(
                        "-fx-background-color: #4F46E5;" +
                        "-fx-text-fill: white;" +
                        "-fx-font-size: 12px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-radius: 8px;" +
                        "-fx-cursor: hand;"
                );


                Region spacer =
                        new Region();

                HBox.setHgrow(
                        spacer,
                        Priority.ALWAYS
                );


                HBox bottomRow =
                        new HBox(
                                skillInfo,
                                spacer,
                                requestButton
                        );

                bottomRow.setAlignment(
                        Pos.CENTER_LEFT
                );


                // ==================================
                // MATCH CARD
                // ==================================

                VBox card =
                        new VBox(
                                18,
                                personHeader,
                                bottomRow
                        );

                card.setPadding(
                        new Insets(22)
                );

                card.setMaxWidth(
                        Double.MAX_VALUE
                );

                card.setStyle(
                        "-fx-background-color: white;" +
                        "-fx-background-radius: 14px;" +
                        "-fx-border-color: #E5E7EB;" +
                        "-fx-border-radius: 14px;"
                );


                requestButton.setOnAction(event -> {

                    sendRequest(
                            userId,
                            matchedUserId,
                            skill,
                            requestButton
                    );
                });


                matchesList
                        .getChildren()
                        .add(card);
            }


            if (!found) {

                Label emptyTitle =
                        new Label(
                                "No matches yet"
                        );

                emptyTitle.setStyle(
                        "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #111827;"
                );


                Label emptyText =
                        new Label(
                                "Add some skills under " +
                                "MY SKILLS to discover " +
                                "your first match."
                        );

                emptyText.setStyle(
                        "-fx-font-size: 14px;" +
                        "-fx-text-fill: #6B7280;"
                );


                VBox emptyBox =
                        new VBox(
                                8,
                                emptyTitle,
                                emptyText
                        );

                emptyBox.setAlignment(
                        Pos.CENTER
                );

                emptyBox.setPadding(
                        new Insets(50)
                );

                matchesList
                        .getChildren()
                        .add(emptyBox);
            }


            rs.close();

            ps.close();

            con.close();


        } catch (Exception e) {

            e.printStackTrace();

            matchesList
                    .getChildren()
                    .add(
                            new Label(
                                    "Unable to load matches."
                            )
                    );
        }
    }


    // ==========================================
    // SEND REQUEST
    // ==========================================

    private void sendRequest(
            int senderId,
            int receiverId,
            String skillRequested,
            Button requestButton) {


        // Find one skill that the current
        // user can teach.

        String findSkillSql =
                "SELECT s.skill_name " +
                "FROM user_skills us " +
                "JOIN skills s " +
                "ON us.skill_id = s.skill_id " +
                "WHERE us.user_id = ? " +
                "AND us.skill_type = 'TEACH' " +
                "LIMIT 1";


        String offeredSkill =
                "Skill exchange";


        String insertSql =
                "INSERT INTO exchange_requests " +
                "(sender_id, receiver_id, " +
                "skill_offered, skill_requested) " +
                "VALUES (?, ?, ?, ?)";


        try {

            Connection con =
                    DatabaseConnection.getConnection();


            PreparedStatement findPs =
                    con.prepareStatement(
                            findSkillSql
                    );

            findPs.setInt(
                    1,
                    senderId
            );


            ResultSet skillRs =
                    findPs.executeQuery();


            if (skillRs.next()) {

                offeredSkill =
                        skillRs.getString(
                                "skill_name"
                        );
            }


            skillRs.close();

            findPs.close();


            PreparedStatement insertPs =
                    con.prepareStatement(
                            insertSql
                    );


            insertPs.setInt(
                    1,
                    senderId
            );

            insertPs.setInt(
                    2,
                    receiverId
            );

            insertPs.setString(
                    3,
                    offeredSkill
            );

            insertPs.setString(
                    4,
                    skillRequested
            );


            insertPs.executeUpdate();


            insertPs.close();

            con.close();


            requestButton.setText(
                    "REQUEST SENT ✓"
            );

            requestButton.setDisable(
                    true
            );

            requestButton.setStyle(
                    "-fx-background-color: #16A34A;" +
                    "-fx-text-fill: white;" +
                    "-fx-font-size: 12px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-radius: 8px;"
            );


        } catch (Exception e) {

            e.printStackTrace();

            requestButton.setText(
                    "REQUEST FAILED"
            );
        }
    }


    // ==========================================
    // GET FIRST LETTER
    // ==========================================

    private String getInitial(
            String name) {

        if (name == null ||
                name.trim().isEmpty()) {

            return "S";
        }

        return name
                .trim()
                .substring(0, 1)
                .toUpperCase();
    }
}
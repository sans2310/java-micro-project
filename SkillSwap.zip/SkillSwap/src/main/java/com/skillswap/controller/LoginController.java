package com.skillswap.controller;

import com.skillswap.util.DatabaseConnection;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    public void showLoginPage(Stage stage) {

        // ==============================
        // LEFT BRANDING SECTION
        // ==============================

        Label logo = new Label("S");
        logo.setStyle(
                "-fx-background-color: white;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 34px;" +
                "-fx-font-weight: bold;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 50%;" +
                "-fx-min-width: 70px;" +
                "-fx-min-height: 70px;" +
                "-fx-max-width: 70px;" +
                "-fx-max-height: 70px;"
        );

        Label brandName =
                new Label("SkillSwap");

        brandName.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 34px;" +
                "-fx-font-weight: bold;"
        );

        Label tagline =
                new Label(
                        "Learn from peers.\n" +
                        "Share your skills.\n" +
                        "Grow together."
                );

        tagline.setStyle(
                "-fx-text-fill: #E0E7FF;" +
                "-fx-font-size: 18px;" +
                "-fx-line-spacing: 8px;"
        );

        Label learn =
                new Label("💡  Learn something new");

        Label connect =
                new Label("🤝  Connect with students");

        Label grow =
                new Label("🚀  Grow your skills");

        learn.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        connect.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        grow.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;"
        );

        VBox benefits =
                new VBox(15);

        benefits.getChildren().addAll(
                learn,
                connect,
                grow
        );

        VBox leftPanel =
                new VBox(22);

        leftPanel.setAlignment(Pos.CENTER_LEFT);
        leftPanel.setPadding(
                new Insets(50)
        );

        leftPanel.setPrefWidth(430);

        leftPanel.setStyle(
                "-fx-background-color: " +
                "linear-gradient(to bottom right, " +
                "#4F46E5, #7C3AED);"
        );

        leftPanel.getChildren().addAll(
                logo,
                brandName,
                tagline,
                benefits
        );


        // ==============================
        // RIGHT LOGIN SECTION
        // ==============================

        Label welcome =
                new Label("Welcome back 👋");

        welcome.setStyle(
                "-fx-font-size: 30px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #111827;"
        );

        Label subtitle =
                new Label(
                        "Sign in to continue your SkillSwap journey."
                );

        subtitle.setStyle(
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #6B7280;"
        );


        Label emailLabel =
                new Label("Email address");

        emailLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        TextField emailField =
                new TextField();

        emailField.setPromptText(
                "Enter your email"
        );

        emailField.setPrefHeight(45);

        emailField.setStyle(
                "-fx-background-color: #F9FAFB;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 8px;" +
                "-fx-background-radius: 8px;" +
                "-fx-padding: 0 14px;" +
                "-fx-font-size: 14px;"
        );


        Label passwordLabel =
                new Label("Password");

        passwordLabel.setStyle(
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #374151;"
        );

        PasswordField passwordField =
                new PasswordField();

        passwordField.setPromptText(
                "Enter your password"
        );

        passwordField.setPrefHeight(45);

        passwordField.setStyle(
                "-fx-background-color: #F9FAFB;" +
                "-fx-border-color: #D1D5DB;" +
                "-fx-border-radius: 8px;" +
                "-fx-background-radius: 8px;" +
                "-fx-padding: 0 14px;" +
                "-fx-font-size: 14px;"
        );


        Button loginButton =
                new Button("LOGIN  →");

        loginButton.setPrefHeight(45);
        loginButton.setMaxWidth(Double.MAX_VALUE);

        loginButton.setStyle(
                "-fx-background-color: #4F46E5;" +
                "-fx-text-fill: white;" +
                "-fx-font-size: 15px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );


        Label newUser =
                new Label("New to SkillSwap?");

        newUser.setStyle(
                "-fx-text-fill: #6B7280;" +
                "-fx-font-size: 13px;"
        );


        Button registerButton =
                new Button("CREATE AN ACCOUNT");

        registerButton.setPrefHeight(40);
        registerButton.setMaxWidth(Double.MAX_VALUE);

        registerButton.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #4F46E5;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-border-color: #4F46E5;" +
                "-fx-border-radius: 8px;" +
                "-fx-background-radius: 8px;" +
                "-fx-cursor: hand;"
        );


        Label message =
                new Label();

        message.setStyle(
                "-fx-text-fill: #DC2626;" +
                "-fx-font-size: 13px;"
        );


        // ==============================
        // LOGIN DATABASE ACTION
        // ==============================

        loginButton.setOnAction(event -> {

            String email =
                    emailField.getText().trim();

            String password =
                    passwordField.getText();

            if (email.isEmpty()
                    || password.isEmpty()) {

                message.setText(
                        "Please enter your email and password."
                );

                return;
            }

            String sql =
                    "SELECT * FROM users " +
                    "WHERE email = ? AND password = ?";

            try {

                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ps.setString(1, email);
                ps.setString(2, password);

                ResultSet rs =
                        ps.executeQuery();

                if (rs.next()) {

                    int userId =
                            rs.getInt("user_id");

                    String userName =
                            rs.getString("name");

                    new DashboardController()
                            .showDashboard(
                                    stage,
                                    userId,
                                    userName
                            );

                } else {

                    message.setText(
                            "Invalid email or password."
                    );
                }

                rs.close();
                ps.close();
                con.close();

            } catch (Exception e) {

                message.setText(
                        "Database connection error."
                );

                e.printStackTrace();
            }
        });


        registerButton.setOnAction(event -> {

            new RegisterController()
                    .showRegisterPage(stage);
        });


        // ==============================
        // RIGHT SIDE LAYOUT
        // ==============================

        VBox loginCard =
                new VBox(12);

        loginCard.setPadding(
                new Insets(45)
        );

        loginCard.setPrefWidth(470);
        loginCard.setMaxWidth(470);

        loginCard.setStyle(
                "-fx-background-color: white;" +
                "-fx-background-radius: 16px;" +
                "-fx-border-color: #E5E7EB;" +
                "-fx-border-radius: 16px;"
        );

        loginCard.getChildren().addAll(
                welcome,
                subtitle,

                createSpacer(10),

                emailLabel,
                emailField,

                passwordLabel,
                passwordField,

                createSpacer(5),

                loginButton,

                createSpacer(5),

                newUser,
                registerButton,

                message
        );


        VBox rightPanel =
                new VBox();

        rightPanel.setAlignment(Pos.CENTER);
        rightPanel.setPrefWidth(570);

        rightPanel.setStyle(
                "-fx-background-color: #F3F4F6;"
        );

        rightPanel.getChildren()
                .add(loginCard);


        // ==============================
        // MAIN LAYOUT
        // ==============================

        HBox mainLayout =
                new HBox(
                        leftPanel,
                        rightPanel
                );

        Scene scene =
                new Scene(
                        mainLayout,
                        1000,
                        650
                );

        stage.setTitle(
                "SkillSwap - Login"
        );

        stage.setScene(scene);

        stage.setMinWidth(900);
        stage.setMinHeight(600);

        stage.show();
    }


    private Region createSpacer(
            double height) {

        Region spacer =
                new Region();

        spacer.setMinHeight(height);

        return spacer;
    }
}